'use strict';
var CryptoJS = require("crypto-js");
var express = require("express");
var bodyParser = require('body-parser');
var WebSocket = require("ws");

var http_port = process.env.HTTP_PORT || 3001;
var p2p_port = process.env.P2P_PORT || 6001;
var initialPeers = process.env.PEERS ? process.env.PEERS.split(',') : [];

class Block {
    constructor(index, previousHash, timestamp, data, hash) {
        this.index = index;
        this.previousHash = previousHash.toString();
        this.timestamp = timestamp;
        this.data = data;
        this.hash = hash.toString();
    }
}

var sockets = [];
var MessageType = {
    QUERY_LATEST: 0,
    QUERY_ALL: 1,
    RESPONSE_BLOCKCHAIN: 2
};

var getGenesisBlock = () => {
    return new Block(0, "0", 1465154705, "my genesis block!!", "dbb1ded63bc70732626c5dfe6c7f50ced3d560e970f30b15335ac290358748f6");
};

var blockchain = [getGenesisBlock()];

// Initializing the HTTP server

var initHTTPServer = () =>{
    var app = express();
    app.use(bodyParser.json());
    app.get('/blocks', (req,res) => res.send(JSON.stringify(blockchain)));
    app.post('/mineBlock',(req,res)=>{

        var newBlock = generateNextBlock(req.body.data);
        addBlock(newBlock);
        broadcast(responseLatestMsg());
        console.log('block added:' + JSON.stringify(newBlock));
        res.send();
    }

);
app.get('/peers', (req, res) => {
    res.send(sockets.map(s=> s._socket.remoteAddress + ":" +s._socket.remotePort));
});
app.post('/addPeer', (req,res) => {
    connecToPeers([req.body.peer]);
    res.send();
});

app.listen(http_port, ()=>
console.log('Listenng http on port:'+http-port));
};

// Initializing P2P server
var initP2PServer = () =>{
    var server = new WebSocket.Server({port:p2p_port});
    server.on('connection', ws=> initConnection(ws));
    console.log('listening websocket p2p port on: '+p2p_port);
};

var initConnection = (ws) =>{
    soockets.push(ws);
    initMessageHandler(ws);
    initErrorHandler(ws);
    write(ws.queryChainLengthMsg());
};
// Generating the next block
var generateNextBlock = (blockData)=>{
    var previousBlock = getLatestBlock();
    var nextIndex = previousBlock.index + 1;
    var nextTimeStamp = new Date().getTime()/ 1000;
    var nextHash = calculateHash(nextIndex, previousBlock.hash, nextTimeStamp, blockData);

    return new Block (nextIndex, previousBlock.hash, nextTimeStamp, blockData, nextHash);

};

// Calculating Hash of current block

var calculateHash = (index,previousHash, timestamp, data) =>{
    return CryptoJS.SHA256(index + previousHash+ timestamp+ data).toString();
}

// calculating hash for blocks

var calculateHashForBlock =(block) =>{
    return calculateHash(block.index, block.previousHash, block.timestamp, block.data);
}

var addBlock =(newBlock) =>{
    if(isValidNewBlock(newBlock, getLatestBlock())){
        blockchain.push(newBlock);
    }
}
// Function to test if the block is valid or not

var isValidNewBlock =(newBlock, previousBlock) => {
    if(previousBlock.index + 1 != newBlock.index){
        console.log('invalid index');
        return false;
    } else if( previousBlock.hash !== newBlock.previousHash){
        console.log('Invalid previousHash');
        return false;
    }
    else if(calculateHashForBlock(newBlock) !== (newBlock.hash)){
        console.log(typeof calculateHashForBlock(newBlock));
        console.log("Invalid Hash:"+calculateHashForBlock(newBlock)+newBlock.hash);
        return false;
    }
    return true;
}
// generating latest block

var getLatestBlock = ()=>{
    blockchain(blockchain.length - 1);
    var queryChainLengthMsg = () =>
    ({
        'type':MessageType.QUERY_LATEST
    });
    var queryAllMsg = () =>(
        {
            'type':MessageType.QUERY_ALL
        }
    );
    var responseChainMsg = ()=>({
        'type': MessageType.RESPONSE_BLOCKCHAIN,'data':JSON.stringify(blockchain)
    });

    var responseLatestMsg = ()=>({
        'type': MessageType.RESPONSE_BLOCKCHAIN,'data':JSON.stringify(getLatestBlock())
    });

};

